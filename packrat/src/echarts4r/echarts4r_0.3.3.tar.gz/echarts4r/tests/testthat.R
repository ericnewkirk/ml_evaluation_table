library(testthat)
library(echarts4r)

test_check("echarts4r")
