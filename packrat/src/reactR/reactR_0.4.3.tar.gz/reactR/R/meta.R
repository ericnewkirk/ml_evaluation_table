#'@keywords internal
react_version <- function(){'16.12.0'}
babel_version <- function(){'6.26.0'}